<?php
/**
 * Kontrakt jednej modyfikacji UI ("tweak"), np. filtrowania menu albo
 * zakładek/pól formularzy. Nowy tweak = nowa klasa implementująca ten
 * interfejs + jedna linia w PluginUicustomTweakRegistry::boot() – bez
 * dotykania plugin_init, panelu admina czy hooków.
 */
interface PluginUicustomTweakInterface
{
    /** Klucz sekcji w JSON configu profilu, np. 'menu', 'forms'. */
    public function getKey(): string;

    public function getDefaultConfig(): array;

    /**
     * Zasoby (ścieżki względne do public/) potrzebne w danym kontekście
     * (aktywny profil, czy ma reguły). Zwracane tylko gdy faktycznie
     * potrzebne – silnik nie ładuje nic "na wszelki wypadek".
     *
     * @return array{css: string[], js: string[]}
     */
    public function getAssets(PluginUicustomContext $context): array;

    /** Filtruje strukturę menu (hook redefine_menus). Bez zmian, jeśli tweak nie dotyczy menu. */
    public function filterMenu(array $menu, array $tweakConfig): array;

    /** Nazwa pola submit, które zapisuje ten tweak na poziomie profilu (np. 'save_menu'). */
    public function getProfileSaveButtonName(): string;

    /** HTML sekcji tego tweaka na stronie profilu (poziom 1 panelu). */
    public function renderProfileSection(array $tweakConfig, int $profilesId, array $catalog): string;

    /** Parsuje $_POST (po sprawdzeniu getProfileSaveButtonName()) i zwraca nowy fragment configu. */
    public function handleProfileSave(array $post, array $tweakConfig, array $catalog): array;
}
