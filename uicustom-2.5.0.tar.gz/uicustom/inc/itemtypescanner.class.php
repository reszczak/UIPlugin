<?php
/**
 * Dynamiczne odkrywanie zakładek i pól formularzy danego itemtype, bez
 * jakiegokolwiek katalogu wpisanego na sztywno w kod. Renderuje każdą
 * zakładkę serwerowo na przykładowym obiekcie i wyłuskuje z HTML:
 * action formularza (*.form.php) oraz data-testid="form-field-<name>".
 */
class PluginUicustomItemtypeScanner
{
    /** ID przykładowego (niekasowanego, nie-szablonu) obiektu itemtype, albo 0. */
    public static function sampleItemId(string $itemtype): int
    {
        global $DB;
        if (!class_exists($itemtype)) {
            return 0;
        }
        $item  = getItemForItemtype($itemtype);
        $table = $item ? $item->getTable() : '';
        if ($table === '' || !$DB->tableExists($table)) {
            return 0;
        }
        $where = [];
        if ($DB->fieldExists($table, 'is_deleted'))  { $where['is_deleted']  = 0; }
        if ($DB->fieldExists($table, 'is_template')) { $where['is_template'] = 0; }
        foreach ($DB->request(['SELECT' => 'id', 'FROM' => $table, 'WHERE' => $where, 'LIMIT' => 1]) as $row) {
            return (int) $row['id'];
        }
        return 0;
    }

    /**
     * @return array{tabs: array<string,string>, forms: array<string,array{label:string,tab:string,fields:array<string,string>}>}
     */
    public static function discover(string $itemtype, int $itemsId): array
    {
        $out = ['tabs' => [], 'forms' => []];
        if (!class_exists($itemtype)) {
            return $out;
        }
        $item = getItemForItemtype($itemtype);
        if (!$item || !$item->getFromDB($itemsId)) {
            return $out;
        }

        $onglets = $item->defineAllTabs(['withtemplate' => 0]);
        unset($onglets['no_all_tab']);

        foreach ($onglets as $key => $label) {
            if ($label === null || $key === -1) {
                continue;
            }
            $cls = explode('$', (string) $key)[0];
            $lbl = trim(preg_replace('/\s+/', ' ', strip_tags((string) $label)));
            if ($cls !== '' && !isset($out['tabs'][$cls])) {
                $out['tabs'][$cls] = $lbl !== '' ? $lbl : $cls;
            }

            // Renderuj treść zakładki i wyłuskaj formularz + pola.
            ob_start();
            try {
                CommonGLPI::displayStandardTab($item, (string) $key, 0, []);
            } catch (\Throwable $e) {
                // pomiń zakładkę, której nie da się wyrenderować w tym kontekście
            }
            $html = (string) ob_get_clean();

            self::extractFormFields($html, $lbl !== '' ? $lbl : $cls, $cls, $out['forms']);
        }

        return $out;
    }

    /** Wyłuskuje z HTML zakładki formularz(e) *.form.php i ich pola (name => label). */
    private static function extractFormFields(string $html, string $tabLabel, string $tabClass, array &$forms): void
    {
        if (!preg_match('/action=["\']([^"\']*\/)?([a-z0-9_]+\.form\.php)/i', $html, $m)) {
            return; // brak edytowalnego formularza w tej zakładce
        }
        $action = strtolower($m[2]);

        // Rejestrujemy formularz tylko, jeśli ma pola (data-testid) – pomijamy
        // zakładki-listy bez edytowalnych pól.
        if (!preg_match_all('/data-testid=["\']form-field-([a-zA-Z0-9_]+)["\']/', $html, $fm)) {
            return;
        }
        if (!isset($forms[$action])) {
            $forms[$action] = ['label' => $tabLabel, 'tab' => $tabClass, 'fields' => []];
        }
        foreach (array_unique($fm[1]) as $name) {
            if (!isset($forms[$action]['fields'][$name])) {
                $forms[$action]['fields'][$name] = self::guessFieldLabel($html, $name);
            }
        }
    }

    /** Próbuje wyciągnąć etykietę pola (tekst <label>) obok data-testid; fallback = name. */
    private static function guessFieldLabel(string $html, string $name): string
    {
        $pos = strpos($html, 'form-field-' . $name);
        if ($pos !== false) {
            $chunk = substr($html, $pos, 600);
            if (preg_match('/<label[^>]*>(.*?)<\/label>/is', $chunk, $lm)) {
                $txt = trim(preg_replace('/\s+/', ' ', strip_tags($lm[1])));
                if ($txt !== '') {
                    return $txt;
                }
            }
        }
        return $name;
    }
}
