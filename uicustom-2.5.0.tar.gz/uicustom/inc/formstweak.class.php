<?php
/**
 * Tweak "forms": zakładki i pola formularzy, per itemtype, wykrywane
 * dynamicznie (PluginUicustomItemtypeScanner) – bez katalogu na sztywno.
 * Jedyny tweak z dodatkowym poziomem edycji (per itemtype), stąd
 * implementuje PluginUicustomItemtypeTweakInterface.
 */
class PluginUicustomFormsTweak implements PluginUicustomItemtypeTweakInterface
{
    public function getKey(): string
    {
        return 'forms';
    }

    public function getDefaultConfig(): array
    {
        return [];
    }

    public function getAssets(PluginUicustomContext $context): array
    {
        if (!$context->hasActiveRule()) {
            return ['css' => [], 'js' => []];
        }
        return ['css' => ['css/hide.css'], 'js' => ['js/profile-ui.js']];
    }

    public function filterMenu(array $menu, array $tweakConfig): array
    {
        return $menu; // ten tweak nie dotyczy menu
    }

    public function getProfileSaveButtonName(): string
    {
        // Poziom 1 tego tweaka to czysta nawigacja (lista + linki do poziomu
        // 2) – nie ma własnego formularza/zapisu, więc ten przycisk nigdy
        // nie jest renderowany i AdminPanel nigdy go nie odbierze.
        return 'uic_forms_profile_save_unused';
    }

    public function renderProfileSection(array $tweakConfig, int $profilesId, array $catalog): string
    {
        $t = [PluginUicustomHtmlHelper::class, 't'];
        $sectorsCat   = $catalog['sectors'] ?? [];
        $itemtypesCat = $catalog['itemtypes'] ?? [];
        $self = PluginUicustomHtmlHelper::selfUrl();
        $card = "style='max-width:1050px;margin:1rem auto'";

        $html = "<div class='card' {$card}><div class='card-body'>";
        $html .= "<h4>" . htmlescape($t('Forms (tabs and fields) per type')) . "</h4>";

        $formsKeys = array_keys($tweakConfig);
        if (!empty($formsKeys)) {
            $html .= "<table class='table table-hover'><tbody>";
            foreach ($formsKeys as $k) {
                $cls = null;
                foreach (array_keys($itemtypesCat) as $c) {
                    if (strtolower($c) === $k) {
                        $cls = $c;
                    }
                }
                $label = $cls !== null ? $itemtypesCat[$cls] : $k;
                $html .= "<tr><td>" . htmlescape($label) . "</td><td class='text-muted small'>" . htmlescape($this->describeItemtype($tweakConfig, $k)) . "</td><td class='text-end'>";
                if ($cls !== null) {
                    $html .= "<a class='btn btn-sm btn-outline-primary' href='" . htmlescape($self . '?profiles_id=' . $profilesId . '&itemtype=' . rawurlencode($cls)) . "'>" . _x('button', 'Edit') . "</a>";
                }
                $html .= "</td></tr>";
            }
            $html .= "</tbody></table>";
        }

        $html .= "<div class='mt-2'><div class='mb-2 text-muted'>" . htmlescape($t('Configure a type (tabs & fields):')) . "</div>";
        foreach ($sectorsCat as $skey => $sdata) {
            if (empty($sdata['itemtypes'])) {
                continue;
            }
            $nconf = 0;
            foreach (array_keys($sdata['itemtypes']) as $c) {
                if (isset($tweakConfig[strtolower($c)])) {
                    $nconf++;
                }
            }
            $open  = ($skey === 'assets' || $nconf > 0) ? ' open' : '';
            $badge = $nconf > 0 ? " <span class='badge bg-primary'>{$nconf}</span>" : '';
            $html .= "<details class='mb-2'{$open}>";
            $html .= "<summary class='fw-bold' style='cursor:pointer'>" . htmlescape($sdata['title']) . "{$badge}</summary>";
            $html .= "<div class='mt-2 ms-3'>";
            foreach ($sdata['itemtypes'] as $cls => $label) {
                $has    = isset($tweakConfig[strtolower($cls)]);
                $clsBtn = $has ? 'btn-primary' : 'btn-outline-secondary';
                $html .= "<a class='btn btn-sm {$clsBtn} me-1 mb-1' href='" . htmlescape($self . '?profiles_id=' . $profilesId . '&itemtype=' . rawurlencode($cls)) . "'>" . htmlescape($label) . "</a>";
            }
            $html .= "</div></details>";
        }
        $html .= "</div></div></div>";

        return $html;
    }

    public function handleProfileSave(array $post, array $tweakConfig, array $catalog): array
    {
        return $tweakConfig; // nie ma formularza na poziomie profilu
    }

    public function describeItemtype(array $tweakConfig, string $itemtypeKey): string
    {
        $rule   = $tweakConfig[$itemtypeKey] ?? [];
        $nforms = count($rule['fields'] ?? []);
        $ntabs  = count($rule['tabs_keep'] ?? []);
        return sprintf(PluginUicustomHtmlHelper::t('%d tabs, %d forms with field rules'), $ntabs, $nforms);
    }

    /* ------------------------- poziom 2: itemtype ------------------------- */

    public function getItemtypeSaveButtonName(): string
    {
        return 'save_forms';
    }

    public function renderItemtypeSection(array $tweakConfig, int $profilesId, string $itemtype, array $catalog): string
    {
        $t   = [PluginUicustomHtmlHelper::class, 't'];
        $key = strtolower($itemtype);
        $itemtypesCat = $catalog['itemtypes'] ?? [];
        $rule  = $tweakConfig[$key] ?? ['tabs_keep' => [], 'fields' => [], 'cleanup' => []];
        $clean = $rule['cleanup'] ?? [];
        $self  = PluginUicustomHtmlHelper::selfUrl();
        $card  = "style='max-width:1050px;margin:1rem auto'";

        $sample = PluginUicustomItemtypeScanner::sampleItemId($itemtype);
        $discat = $sample > 0 ? PluginUicustomItemtypeScanner::discover($itemtype, $sample) : ['tabs' => [], 'forms' => []];

        $html  = "<form method='post' action='" . htmlescape($self) . "'>";
        $html .= PluginUicustomHtmlHelper::csrfAndProfileHidden($profilesId);
        $html .= Html::hidden('itemtype', ['value' => $itemtype]);
        $html .= "<div class='card' {$card}><div class='card-body'>";
        $html .= "<div class='d-flex justify-content-between align-items-center mb-3'>";
        $html .= "<h3 class='m-0'>" . htmlescape(($itemtypesCat[$itemtype] ?? $itemtype)) . "</h3>";
        $html .= "<a class='btn btn-sm btn-outline-secondary' href='" . htmlescape($self . '?profiles_id=' . $profilesId) . "'>← " . __('Profile') . "</a>";
        $html .= "</div>";

        if ($sample <= 0) {
            $html .= "<div class='alert alert-warning'>" . htmlescape($t('No sample object of this type exists in GLPI – create one to scan available tabs and fields.')) . "</div>";
        } elseif (empty($discat['forms'])) {
            $html .= "<div class='alert alert-warning'>" . htmlescape($t('No editable fields detected for this type.')) . "</div>";
        }

        $html .= "<table class='table'>";
        $html .= "<tr><th style='width:30%'>" . htmlescape($t('Tabs – keep')) . "</th><td>";
        if (!empty($discat['tabs'])) {
            ob_start();
            Dropdown::showFromArray('tabs_keep', $discat['tabs'], ['values' => $rule['tabs_keep'] ?? [], 'multiple' => true, 'width' => '100%']);
            $html .= ob_get_clean();
        } else {
            $html .= "<em class='text-muted'>" . htmlescape($t('(no data – a sample object is required)')) . "</em>";
        }
        $html .= "</td></tr></table>";

        $kept = $rule['tabs_keep'] ?? [];
        $tabsWithForm = [];
        $fi = 0;
        $html .= "<h5 class='mt-3'>" . htmlescape($t('Form fields')) . "</h5>";
        foreach ($discat['forms'] as $action => $meta) {
            $tabcls = $meta['tab'] ?? '';
            if (!empty($kept) && $tabcls !== '' && !in_array($tabcls, $kept, true)) {
                continue;
            }
            $tabsWithForm[] = $tabcls;
            $frule = $rule['fields'][$action] ?? ['mode' => 'keep', 'list' => array_keys($meta['fields'])];
            $mode  = ($frule['mode'] ?? 'keep') === 'hide' ? 'hide' : 'keep';
            $html .= Html::hidden("field_action_{$fi}", ['value' => $action]);
            $html .= "<div class='border rounded p-2 mb-2'>";
            $html .= "<div class='d-flex align-items-center gap-2 mb-2'><strong>" . htmlescape($meta['label']) . "</strong> <span class='text-muted small'>(" . htmlescape($action) . ")</span></div>";
            $html .= "<div class='mb-2 d-flex align-items-center gap-2'><span>" . htmlescape($t('Mode:')) . "</span>";
            ob_start();
            Dropdown::showFromArray("field_mode_{$fi}", ['keep' => $t('Keep only selected'), 'hide' => $t('Hide selected')], ['value' => $mode, 'width' => '220px']);
            $html .= ob_get_clean();
            $html .= "</div>";
            ob_start();
            Dropdown::showFromArray("field_list_{$fi}", $meta['fields'], ['values' => $frule['list'] ?? [], 'multiple' => true, 'width' => '100%']);
            $html .= ob_get_clean();
            $html .= "</div>";
            $fi++;
        }
        if ($fi === 0 && !empty($discat['forms'])) {
            $html .= "<div class='text-muted mb-2'>" . htmlescape($t('None of the kept tabs has editable fields.')) . "</div>";
        }
        if (!empty($kept)) {
            $listonly = array_diff($kept, array_filter($tabsWithForm));
            if (!empty($listonly)) {
                $labels = [];
                foreach ($listonly as $c) {
                    $labels[] = $discat['tabs'][$c] ?? $c;
                }
                $html .= "<div class='alert alert-secondary py-2'>" . htmlescape(sprintf(
                    $t('Tabs without editable fields (sub-item lists): %s. They can only be kept/hidden as a whole above.'),
                    implode(', ', $labels)
                )) . "</div>";
            }
        }

        $html .= "<table class='table'><tr><th style='width:30%'>" . htmlescape($t('Cosmetics')) . "</th><td>";
        $html .= PluginUicustomHtmlHelper::checkbox('hide_qr', !empty($clean['hide_qr']), $t('Hide QR / Asset URL card'));
        $html .= PluginUicustomHtmlHelper::checkbox('hide_all_tab', !empty($clean['hide_all_tab']), $t('Hide the "All" tab'));
        $html .= PluginUicustomHtmlHelper::checkbox('fix_fa_info', !isset($clean['fix_fa_info']) || !empty($clean['fix_fa_info']), $t('Fix the dropdown "i" icon'));
        $html .= "</td></tr></table>";

        $html .= "<div class='alert alert-info'>" . htmlescape(sprintf(
            $t('Mode "Keep only selected" = whitelist. "Hide selected" = blacklist. Fields detected from object #%d.'),
            $sample
        )) . "</div>";

        $html .= "<div class='d-flex justify-content-between'>";
        $html .= "<button type='submit' name='delete_itemtype' value='1' class='btn btn-outline-danger'>" . htmlescape($t('Delete rule for this type')) . "</button>";
        $html .= "<button type='submit' name='" . $this->getItemtypeSaveButtonName() . "' value='1' class='btn btn-primary'>" . _x('button', 'Save') . "</button>";
        $html .= "</div>";
        $html .= "</div></div></form>";

        return $html;
    }

    public function handleItemtypeSave(array $post, array $tweakConfig, string $itemtype): array
    {
        $key = strtolower($itemtype);
        if (!isset($tweakConfig[$key])) {
            $tweakConfig[$key] = ['tabs_keep' => [], 'fields' => [], 'cleanup' => []];
        }

        $tweakConfig[$key]['tabs_keep'] = self::sanitizeTabsList((array) ($post['tabs_keep'] ?? []));

        $fields = [];
        for ($i = 0; isset($post["field_action_{$i}"]); $i++) {
            $action = (string) $post["field_action_{$i}"];
            $rule   = self::sanitizeFieldRule($action, [
                'mode' => $post["field_mode_{$i}"] ?? 'keep',
                'list' => (array) ($post["field_list_{$i}"] ?? []),
            ]);
            if ($rule !== null) {
                $fields[strtolower($action)] = $rule;
            }
        }
        // MERGE zamiast nadpisania: reguły formularzy niewyrenderowanych w tym
        // widoku (np. odznaczona zakładka) są zachowywane, nie tracone.
        $tweakConfig[$key]['fields'] = array_merge($tweakConfig[$key]['fields'] ?? [], $fields);

        $tweakConfig[$key]['cleanup'] = [
            'hide_qr'      => isset($post['hide_qr']),
            'hide_all_tab' => isset($post['hide_all_tab']),
            'fix_fa_info'  => isset($post['fix_fa_info']),
        ];

        return $tweakConfig;
    }

    public function handleItemtypeDelete(array $tweakConfig, string $itemtype): array
    {
        unset($tweakConfig[strtolower($itemtype)]);
        return $tweakConfig;
    }

    /**
     * Walidacja wspólna z ajax/save_rule.php (tryb edycji "na żywo"), żeby
     * whitelisty nazw zakładek/pól nie były duplikowane w dwóch miejscach.
     */
    public static function sanitizeTabsList(array $raw): array
    {
        $tabs = [];
        foreach ($raw as $tb) {
            if (is_string($tb) && preg_match('/^[A-Za-z0-9_\\\\]+$/', $tb)) {
                $tabs[] = $tb;
            }
        }
        return array_values(array_unique($tabs));
    }

    /** @return array{mode:string,list:string[]}|null null = akcja odrzucona (nie przeszła whitelisty). */
    public static function sanitizeFieldRule(string $action, array $rule): ?array
    {
        if (!preg_match('/^[a-z0-9_]+\.form\.php$/i', $action)) {
            return null;
        }
        $mode = (($rule['mode'] ?? 'keep') === 'hide') ? 'hide' : 'keep';
        $list = [];
        foreach ((array) ($rule['list'] ?? []) as $f) {
            if (is_string($f) && preg_match('/^[A-Za-z0-9_]+$/', $f)) {
                $list[] = $f;
            }
        }
        return ['mode' => $mode, 'list' => array_values(array_unique($list))];
    }
}
