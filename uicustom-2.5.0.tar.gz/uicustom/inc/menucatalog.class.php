<?php
/**
 * Katalog całego menu GLPI (dla panelu): sektory, ich pozycje i itemtype'y.
 * Dzięki temu panel nie jest ograniczony do jednego sektora (np. Assets).
 * Uruchamiane w sesji admina, który widzi pełne menu.
 */
class PluginUicustomMenuCatalog
{
    /**
     * @return array{
     *   sectors: array<string, array{title:string, items: array<string,string>, itemtypes: array<string,string>}>,
     *   itemtypes: array<string,string>
     * }
     */
    public static function build(): array
    {
        $menu      = Html::generateMenuSession(true);
        $sectors   = [];
        $itemtypes = [];

        foreach ($menu as $skey => $sdata) {
            if (!is_array($sdata) || !isset($sdata['title'])) {
                continue;
            }
            // Tylko realne sektory najwyższego poziomu (mają listę 'types');
            // pomija pseudo-wpisy (statusy, filtry) i pozycje specjalne.
            if (!array_key_exists('types', $sdata) || in_array($skey, ['preference'], true)) {
                continue;
            }
            $items = [];
            foreach (($sdata['content'] ?? []) as $ikey => $idata) {
                if (is_array($idata) && isset($idata['title'])) {
                    $items[$ikey] = trim(strip_tags((string) $idata['title']));
                }
            }

            // itemtype'y z listy 'types' – tylko realne obiekty formularzowe
            // (CommonDBTM); odsiewa wewnętrzne narzędzia (LogViewer itp.).
            $stypes = [];
            foreach (($sdata['types'] ?? []) as $cls) {
                if (is_string($cls) && class_exists($cls) && is_subclass_of($cls, CommonDBTM::class)) {
                    $label = $items[strtolower($cls)] ?? $cls;
                    $stypes[$cls]    = $label;
                    $itemtypes[$cls] = $label;
                }
            }
            asort($stypes);

            $sectors[$skey] = [
                'title'     => trim(strip_tags((string) $sdata['title'])),
                'items'     => $items,
                'itemtypes' => $stypes,
            ];
        }

        asort($itemtypes);
        return ['sectors' => $sectors, 'itemtypes' => $itemtypes];
    }

    /** Czy $itemtype jest realnym itemtype'em obecnym w katalogu menu. */
    public static function isKnownItemtype(string $itemtype, array $catalog): bool
    {
        return isset($catalog['itemtypes'][$itemtype]);
    }
}
