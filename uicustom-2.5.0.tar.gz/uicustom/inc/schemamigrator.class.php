<?php
/**
 * Wersjonowanie schematu configu profilu. Jedno miejsce na kompatybilność
 * wsteczną, zamiast osobnych fallbacków rozsianych po setup.php,
 * front/config.form.php i JS (stan przed refaktoryzacją).
 *
 * Migracja odbywa się na ODCZYCIE (w PluginUicustomProfileConfigRepository).
 * Nic nie jest zapisywane wstecznie automatycznie – każdy kolejny zapis
 * (z panelu/edit-mode) naturalnie utrwala już bieżący schemat.
 */
class PluginUicustomSchemaMigrator
{
    public const CURRENT_VERSION = 2;

    public static function migrate(array $config): array
    {
        $version = (int) ($config['_v'] ?? 1);

        if ($version < 2) {
            $config = self::migrateV1ToV2($config);
        }

        $config['_v'] = self::CURRENT_VERSION;
        return $config;
    }

    /**
     * v1 -> v2: `menu.assets_keep` (tylko Assets) -> `menu.sector_keep.assets`
     * (uniwersalne, dowolny sektor); `menu.hide_dashboard` (tylko Assets)
     * -> `menu.hide_dashboards` (globalne).
     */
    private static function migrateV1ToV2(array $config): array
    {
        $menu = $config['menu'] ?? [];

        if (isset($menu['assets_keep']) && !isset($menu['sector_keep']['assets'])) {
            $menu['sector_keep']['assets'] = $menu['assets_keep'];
        }
        unset($menu['assets_keep']);

        if (!empty($menu['hide_dashboard']) && empty($menu['hide_dashboards'])) {
            $menu['hide_dashboards'] = true;
        }
        unset($menu['hide_dashboard']);

        $config['menu'] = $menu;
        return $config;
    }
}
