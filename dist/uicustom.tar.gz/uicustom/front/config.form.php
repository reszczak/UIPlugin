<?php

Session::checkRight('config', UPDATE);

(new PluginUicustomAdminPanel())->run();
