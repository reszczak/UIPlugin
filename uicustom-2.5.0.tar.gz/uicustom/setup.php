<?php
/**
 * UI Customizer – konfigurowalny plugin GLPI 11.x do upraszczania UI per profil.
 *
 * Architektura (v2.0): silnik + rejestr "tweaków" (inc/tweakinterface.class.php).
 * Ten plik jest wyłącznie bootstrapem hooków GLPI – logika biznesowa żyje
 * w klasach pod inc/ (autoload przez konwencję GLPI: PluginUicustomFoo ->
 * inc/foo.class.php). Zero modyfikacji rdzenia GLPI.
 */

define('PLUGIN_UICUSTOM_VERSION', '2.5.0');
define('PLUGIN_UICUSTOM_MIN_GLPI', '11.0.0');
define('PLUGIN_UICUSTOM_MAX_GLPI', '11.99.99');
define('PLUGIN_UICUSTOM_TABLE', 'glpi_plugin_uicustom_profileconfigs');

function plugin_init_uicustom(): void
{
    global $PLUGIN_HOOKS, $CFG_GLPI;

    $PLUGIN_HOOKS['csrf_compliant']['uicustom'] = true;

    // Tłumaczenia (domena 'uicustom') wg aktywnego języka. Format 'phparray'
    // (plik PHP zwracający mapę), bo środowisko bywa bez msgfmt do .mo.
    $lang = $_SESSION['glpilanguage'] ?? ($CFG_GLPI['language'] ?? '');
    $phpfile = __DIR__ . '/locales/' . $lang . '.php';
    if ($lang !== '' && is_file($phpfile) && isset($GLOBALS['TRANSLATE'])) {
        $GLOBALS['TRANSLATE']->addTranslationFile('phparray', $phpfile, 'uicustom', $lang);
    }

    // Panel konfiguracji (broniony w skrypcie: config/UPDATE = tylko admin).
    $PLUGIN_HOOKS['config_page']['uicustom'] = 'front/config.form.php';

    // Serwerowe filtrowanie menu wg reguły aktywnego profilu.
    $PLUGIN_HOOKS['redefine_menus']['uicustom'] = 'plugin_uicustom_redefine_menus';

    // Zasoby JS/CSS: każdy tweak deklaruje sam, czego potrzebuje w danym
    // kontekście – plugin_init nie wie nic o konkretnych plikach.
    $context  = new PluginUicustomContext(new PluginUicustomProfileConfigRepository());
    $registry = (new PluginUicustomAssetRegistry())->collect($context);
    $registry->applyToHooks($PLUGIN_HOOKS);

    // UWAGA: NIE rejestrować tu add_css_anonymous_page -> ajax/branding.css.php.
    // Zweryfikowane: dodatkowe żądanie przez pełny kernel GLPI podczas
    // renderowania strony logowania psuje token CSRF formularza logowania
    // ("Akcja nie jest możliwa" przy próbie zalogowania). Login firmowego
    // logo wymaga innego mechanizmu niż CSS ładowany jak zwykły plugin-asset
    // (patrz TODO w PluginUicustomBrandingSettings) – do zaprojektowania.
}

function plugin_version_uicustom(): array
{
    return [
        'name'         => 'UI Customizer',
        'version'      => PLUGIN_UICUSTOM_VERSION,
        'author'       => 'Ops',
        'license'      => 'GPLv3',
        'homepage'     => '',
        'requirements' => [
            'glpi' => ['min' => PLUGIN_UICUSTOM_MIN_GLPI, 'max' => PLUGIN_UICUSTOM_MAX_GLPI],
        ],
    ];
}

function plugin_uicustom_check_prerequisites(): bool
{
    if (version_compare(GLPI_VERSION, PLUGIN_UICUSTOM_MIN_GLPI, 'lt')) {
        echo "UI Customizer wymaga GLPI >= " . PLUGIN_UICUSTOM_MIN_GLPI;
        return false;
    }
    return true;
}

function plugin_uicustom_check_config(): bool
{
    return true;
}

/**
 * Hook REDEFINE_MENUS: GLPI wymaga nazwy funkcji globalnej (string) jako
 * entry point – ta funkcja jedynie delegowuje do tweaków, które deklarują
 * filtrowanie menu (dziś: PluginUicustomMenuTweak).
 */
function plugin_uicustom_redefine_menus(array $menu): array
{
    $context = new PluginUicustomContext(new PluginUicustomProfileConfigRepository());
    $cfg = $context->activeConfig();
    if ($cfg === null) {
        return $menu;
    }
    foreach (PluginUicustomTweakRegistry::all() as $tweak) {
        $tweakConfig = $cfg[$tweak->getKey()] ?? $tweak->getDefaultConfig();
        $menu = $tweak->filterMenu($menu, $tweakConfig);
    }
    return $menu;
}
