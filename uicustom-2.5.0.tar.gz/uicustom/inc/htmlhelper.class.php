<?php
/**
 * Drobne helpery HTML wspólne dla wszystkich tweaków renderujących panel
 * admina, żeby nie duplikować tego samego znacznika w każdej klasie.
 */
class PluginUicustomHtmlHelper
{
    public static function checkbox(string $name, bool $checked, string $label): string
    {
        $c = $checked ? 'checked' : '';
        return "<label class='form-check'><input type='checkbox' class='form-check-input' name='{$name}' value='1' {$c}> "
            . "<span class='form-check-label'>" . htmlescape($label) . "</span></label>";
    }

    public static function csrfAndProfileHidden(int $profilesId): string
    {
        return Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()])
            . Html::hidden('profiles_id', ['value' => $profilesId]);
    }

    /** Etykieta tłumaczona w domenie 'uicustom'. Zwraca surowy tekst – escape przy echo. */
    public static function t(string $s): string
    {
        return __($s, 'uicustom');
    }

    /** URL panelu, root-relative – $_SERVER['PHP_SELF'] w skryptach pluginu to /index.php, nie da się użyć. */
    public static function selfUrl(): string
    {
        return self::pluginDir() . 'front/config.form.php';
    }

    /** Root-relative katalog pluginu (z końcowym /), do budowania linków do ajax/ itp. */
    public static function pluginDir(): string
    {
        global $CFG_GLPI;
        return ($CFG_GLPI['root_doc'] ?? '') . '/plugins/uicustom/';
    }
}
