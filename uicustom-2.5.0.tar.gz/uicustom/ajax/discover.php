<?php
/**
 * Admin-only: skanuje itemtype i zwraca katalog zakładek/pól (JSON).
 * Używane przez panel konfiguracji do dynamicznego budowania edytora.
 * GET: itemtype, items_id (opcjonalnie – domyślnie pierwszy obiekt).
 */

Session::checkRight('config', UPDATE);
header('Content-Type: application/json; charset=utf-8');

$itemtype = (string) ($_GET['itemtype'] ?? '');
$itemsId  = (int) ($_GET['items_id'] ?? 0);

$catalog = PluginUicustomMenuCatalog::build();
if ($itemtype === '' || !PluginUicustomMenuCatalog::isKnownItemtype($itemtype, $catalog)) {
    echo json_encode(['error' => 'invalid itemtype']);
    return;
}
if ($itemsId <= 0) {
    $itemsId = PluginUicustomItemtypeScanner::sampleItemId($itemtype);
}
if ($itemsId <= 0) {
    echo json_encode(['error' => 'no_sample_item', 'itemtype' => $itemtype]);
    return;
}

echo json_encode(
    PluginUicustomItemtypeScanner::discover($itemtype, $itemsId) + ['items_id' => $itemsId],
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);
