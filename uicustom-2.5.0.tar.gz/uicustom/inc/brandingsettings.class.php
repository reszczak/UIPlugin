<?php
/**
 * Branding globalny wtyczki – NIEZALEŻNY od reguł per profil, jedno
 * ustawienie na całą instancję. Przechowywane w natywnym Config (kontekst
 * 'plugin:uicustom'), tak jak dawna konfiguracja globalna fazy 1 (patrz
 * hook.php – migracja).
 *
 * Cztery części, wszystkie nadpisują zmienne CSS, które GLPI JUŻ ma (nie
 * "hackujemy" żadnego selektora na siłę, GLPI zaprojektował to jako
 * motywowalne – patrz css/includes/_base.scss w rdzeniu GLPI):
 * - Kolor podstawowy/akcentu (--tblr-primary) – przyciski "+", highlighty.
 *   Ma dwie "cień" zmienne (--tblr-primary-rgb dla rgba() w focus
 *   ring/subtelnych tłach, --tblr-primary-fg dla kontrastującego tekstu na
 *   przycisku) liczone automatycznie z głównego koloru, nie osobne pola.
 * - Kolor linków (--tblr-link-color) – nazwy obiektów w listach/formularzach
 *   (np. "TEST-DEMO-PC"). Osobna zmienna od --tblr-primary (GLPI ich nie
 *   wiąże), z osobnym liczonym hover-shade (--tblr-link-hover-color(-rgb)).
 * - Kolory paska bocznego/topbara (--glpi-mainmenu-bg/-fg).
 * - Logo firmy (--glpi-logo-*) – obraz trzymany w bazie (base64), serwowany
 *   przez ajax/logo.php – działa niezależnie od tego, czy katalog pluginu
 *   jest zamontowany read-only (Docker) czy jest symlinkiem z repo Git.
 *
 * Renderowane jako CSS przez ajax/branding.css.php, ładowane wyłącznie dla
 * zalogowanego użytkownika (patrz notatka tam – NIE dodawać na ekran
 * logowania, psuje CSRF).
 */
class PluginUicustomBrandingSettings
{
    private const CONTEXT = 'plugin:uicustom';

    /** klucz configu => natywna zmienna CSS GLPI, którą steruje. */
    public const CSS_VARS = [
        'brand_primary'    => '--tblr-primary',
        'brand_link'       => '--tblr-link-color',
        'brand_sidebar_bg' => '--glpi-mainmenu-bg',
        'brand_sidebar_fg' => '--glpi-mainmenu-fg',
    ];

    /** Zmienne natywne GLPI nadpisywane logo firmy (jeden obraz do wszystkich wariantów). */
    private const LOGO_CSS_VARS = [
        '--glpi-logo-light',
        '--glpi-logo-dark',
        '--glpi-logo-light-reduced',
        '--glpi-logo-dark-reduced',
        '--glpi-logo-light-login',
        '--glpi-logo-dark-login',
    ];

    private const LOGO_MAX_BYTES = 300 * 1024; // 300 KB - wystarczające na logo, nie rozdmuchuje glpi_configs
    private const LOGO_ALLOWED_MIMES = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];

    /** Domyślne wartości GLPI (css/includes/_base.scss) – "reset" wraca do NATYWNEGO wyglądu, nie do naszych własnych domyślnych. */
    public static function defaults(): array
    {
        return [
            'brand_primary'    => '#fec95c', // rgb(254,201,92) - domyślny --tblr-primary-rgb GLPI
            'brand_link'       => '#3a5693', // rgb(58,86,147) - domyślny --tblr-link-color-rgb GLPI
            'brand_sidebar_bg' => '#2f3f64',
            'brand_sidebar_fg' => '#f4f6fa',
        ];
    }

    /** Etykiety pól koloru do formularza admina. */
    public static function labels(): array
    {
        return [
            'brand_primary'    => 'Primary / accent color (buttons, "+", highlights)',
            'brand_link'       => 'Link color (item names in lists/forms, e.g. "TEST-DEMO-PC")',
            'brand_sidebar_bg' => 'Sidebar / top bar background color',
            'brand_sidebar_fg' => 'Sidebar / top bar text color',
        ];
    }

    public static function logoCssVars(): array
    {
        return self::LOGO_CSS_VARS;
    }

    /** "#rrggbb" -> "r, g, b" (dla --tblr-primary-rgb, konsumowanego przez rgba() w focus-ring/subtelnych tłach Tablera). */
    public static function hexToRgbTriple(string $hex): string
    {
        [$r, $g, $b] = sscanf($hex, '#%02x%02x%02x');
        return "{$r}, {$g}, {$b}";
    }

    /** Biały albo ciemny tekst – w zależności od tego, co daje lepszy kontrast na danym tle (prosta luminancja WCAG-ish). */
    public static function contrastingForeground(string $hex): string
    {
        [$r, $g, $b] = sscanf($hex, '#%02x%02x%02x');
        $luminance = (0.299 * $r + 0.587 * $g + 0.114 * $b) / 255;
        return $luminance > 0.6 ? '#1e293b' : '#ffffff';
    }

    /**
     * Przyciemnia kolor o $percent w stronę czarnego – dla stanu hover linków.
     * GLPI liczy --tblr-primary-darken jako color-mix() na żywo (automatycznie
     * podłapuje nasz --tblr-primary), ale --tblr-link-hover-color(-rgb) NIE ma
     * takiego mostka w rdzeniu GLPI, więc musimy policzyć wartość sami w PHP
     * (color-mix() nie da się "odczytać" z powrotem jako liczby w czystym CSS).
     */
    public static function darken(string $hex, float $percent): string
    {
        [$r, $g, $b] = sscanf($hex, '#%02x%02x%02x');
        $factor = 1 - $percent;
        $r = (int) round($r * $factor);
        $g = (int) round($g * $factor);
        $b = (int) round($b * $factor);
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }

    /* ------------------------------ kolory ------------------------------ */

    /** Aktualne wartości (uzupełnione defaultami dla brakujących/niepoprawnych). */
    public function get(): array
    {
        $stored = Config::getConfigurationValues(self::CONTEXT, array_keys(self::CSS_VARS));
        $out = self::defaults();
        foreach (self::CSS_VARS as $key => $cssVar) {
            $value = (string) ($stored[$key] ?? '');
            if ($value !== '' && self::isValidHexColor($value)) {
                $out[$key] = $value;
            }
        }
        return $out;
    }

    public function save(array $post): void
    {
        $clean = [];
        foreach (self::CSS_VARS as $key => $cssVar) {
            $value = (string) ($post[$key] ?? '');
            if (self::isValidHexColor($value)) {
                $clean[$key] = $value;
            }
        }
        if (!empty($clean)) {
            Config::setConfigurationValues(self::CONTEXT, $clean);
        }
    }

    public function reset(): void
    {
        Config::deleteConfigurationValues(self::CONTEXT, array_keys(self::CSS_VARS));
    }

    public static function isValidHexColor(string $v): bool
    {
        return (bool) preg_match('/^#[0-9a-fA-F]{6}$/', $v);
    }

    /* ------------------------------- logo -------------------------------- */

    public function hasLogo(): bool
    {
        $stored = Config::getConfigurationValues(self::CONTEXT, ['brand_logo_data']);
        return !empty($stored['brand_logo_data']);
    }

    /** @return array{mime:string,data:string}|null dane binarne (już zdekodowane z base64). */
    public function getLogo(): ?array
    {
        $stored = Config::getConfigurationValues(self::CONTEXT, ['brand_logo_data', 'brand_logo_mime']);
        if (empty($stored['brand_logo_data']) || empty($stored['brand_logo_mime'])) {
            return null;
        }
        $data = base64_decode((string) $stored['brand_logo_data'], true);
        if ($data === false) {
            return null;
        }
        return ['mime' => (string) $stored['brand_logo_mime'], 'data' => $data];
    }

    /** Znacznik czasu ostatniej zmiany logo – do cache-bustingu URL obrazu. */
    public function logoUpdatedAt(): int
    {
        $stored = Config::getConfigurationValues(self::CONTEXT, ['brand_logo_updated']);
        return (int) ($stored['brand_logo_updated'] ?? 0);
    }

    /**
     * Waliduje i zapisuje wgrany plik logo (wpis z $_FILES).
     *
     * @throws RuntimeException gdy plik nie przejdzie walidacji (komunikat do wyświetlenia adminowi).
     */
    public function saveLogo(array $file): void
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new RuntimeException(__('File upload failed.', 'uicustom'));
        }
        $tmpPath = (string) ($file['tmp_name'] ?? '');
        if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
            throw new RuntimeException(__('File upload failed.', 'uicustom'));
        }
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > self::LOGO_MAX_BYTES) {
            throw new RuntimeException(sprintf(
                __('Logo file is too large (max %d KB).', 'uicustom'),
                (int) (self::LOGO_MAX_BYTES / 1024)
            ));
        }
        // Nie ufamy $file['type'] (nagłówek od klienta) – realny MIME z zawartości pliku.
        $mime = Toolbox::getMime($tmpPath);
        if (!in_array($mime, self::LOGO_ALLOWED_MIMES, true)) {
            throw new RuntimeException(__('Unsupported image format. Use PNG, JPEG, GIF or WebP.', 'uicustom'));
        }

        $data = file_get_contents($tmpPath);
        if ($data === false) {
            throw new RuntimeException(__('File upload failed.', 'uicustom'));
        }

        Config::setConfigurationValues(self::CONTEXT, [
            'brand_logo_data'    => base64_encode($data),
            'brand_logo_mime'    => $mime,
            'brand_logo_updated' => (string) time(),
        ]);
    }

    public function removeLogo(): void
    {
        Config::deleteConfigurationValues(self::CONTEXT, ['brand_logo_data', 'brand_logo_mime', 'brand_logo_updated']);
    }
}
