<?php
/**
 * Panel konfiguracji UI Customizer – dostęp: tylko administrator.
 * Cała logika żyje w PluginUicustomAdminPanel + tweakach (inc/); ten plik
 * jest wyłącznie punktem wejścia chronionym prawem GLPI.
 */

Session::checkRight('config', UPDATE);

(new PluginUicustomAdminPanel())->run();
