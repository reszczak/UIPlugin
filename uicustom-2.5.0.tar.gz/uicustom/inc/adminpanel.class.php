<?php
/**
 * Panel konfiguracji – dispatcher generyczny wobec tweaków. Nie zna
 * żadnego tweaka z nazwy: iteruje PluginUicustomTweakRegistry::all() i
 * renderuje/obsługuje POST każdego z nich po jego własnym kontrakcie
 * (PluginUicustomTweakInterface / PluginUicustomItemtypeTweakInterface).
 *
 * Rzeczy, które NIE są tweakiem (bo dotyczą całego wiersza configu, nie
 * jednej modyfikacji UI) – status is_active i usunięcie reguły – panel
 * obsługuje sam.
 */
class PluginUicustomAdminPanel
{
    private PluginUicustomProfileConfigRepository $repo;

    public function __construct(?PluginUicustomProfileConfigRepository $repo = null)
    {
        $this->repo = $repo ?? new PluginUicustomProfileConfigRepository();
    }

    public function run(): void
    {
        $self    = PluginUicustomHtmlHelper::selfUrl();
        $catalog = PluginUicustomMenuCatalog::build();

        // CSRF weryfikuje automatycznie kernel (CheckCsrfListener).
        $this->handlePost($self, $catalog);

        $allProfiles = $this->allProfiles();

        Html::header('UI Customizer', $self, 'config', 'plugins');

        $this->renderProfilesList($self, $allProfiles);
        $this->renderBranding($self);

        $editPid  = (int) ($_GET['profiles_id'] ?? 0);
        $editType = (string) ($_GET['itemtype'] ?? '');

        if ($editPid > 0 && isset($allProfiles[$editPid]) && $editType !== '' && PluginUicustomMenuCatalog::isKnownItemtype($editType, $catalog)) {
            $this->renderItemtypeLevel($editPid, $editType, $catalog);
        } elseif ($editPid > 0 && isset($allProfiles[$editPid])) {
            $this->renderProfileLevel($editPid, $catalog, $allProfiles);
        }

        Html::footer();
    }

    /* ------------------------------ POST ------------------------------- */

    private function handlePost(string $self, array $catalog): void
    {
        if (isset($_POST['delete'])) {
            $pid = (int) ($_POST['profiles_id'] ?? 0);
            if ($pid > 0) {
                $this->repo->delete($pid);
                Session::addMessageAfterRedirect(__('Item successfully deleted'));
            }
            Html::redirect($self);
        }

        if (isset($_POST['save_branding'])) {
            $settings = new PluginUicustomBrandingSettings();
            $settings->save($_POST);
            if (!empty($_FILES['logo']['name'])) {
                try {
                    $settings->saveLogo($_FILES['logo']);
                } catch (RuntimeException $e) {
                    Session::addMessageAfterRedirect(htmlescape($e->getMessage()), true, ERROR);
                    Html::redirect($self);
                }
            }
            Session::addMessageAfterRedirect(__('Configuration saved successfully.'));
            Html::redirect($self);
        }

        if (isset($_POST['reset_branding'])) {
            (new PluginUicustomBrandingSettings())->reset();
            Session::addMessageAfterRedirect(__('Configuration saved successfully.'));
            Html::redirect($self);
        }

        if (isset($_POST['remove_logo'])) {
            (new PluginUicustomBrandingSettings())->removeLogo();
            Session::addMessageAfterRedirect(__('Item successfully deleted'));
            Html::redirect($self);
        }

        if (isset($_POST['save_status'])) {
            $pid = (int) ($_POST['profiles_id'] ?? 0);
            if ($pid > 0) {
                $cfg = $this->repo->getRaw($pid) ?? PluginUicustomProfileConfigRepository::defaultConfig();
                $this->repo->save($pid, $cfg, isset($_POST['is_active']));
                Session::addMessageAfterRedirect(__('Configuration saved successfully.'));
            }
            Html::redirect($self . '?profiles_id=' . $pid);
        }

        foreach (PluginUicustomTweakRegistry::all() as $tweak) {
            $this->handleTweakProfileSave($tweak, $self, $catalog);
            if ($tweak instanceof PluginUicustomItemtypeTweakInterface) {
                $this->handleTweakItemtypeSave($tweak, $self);
                $this->handleTweakItemtypeDelete($tweak, $self);
            }
        }
    }

    private function handleTweakProfileSave(PluginUicustomTweakInterface $tweak, string $self, array $catalog): void
    {
        if (!isset($_POST[$tweak->getProfileSaveButtonName()])) {
            return;
        }
        $pid = (int) ($_POST['profiles_id'] ?? 0);
        if ($pid > 0) {
            $wasNew = $this->repo->getRaw($pid) === null;
            $cfg    = $this->repo->getRaw($pid) ?? PluginUicustomProfileConfigRepository::defaultConfig();
            $key    = $tweak->getKey();
            $cfg[$key] = $tweak->handleProfileSave($_POST, $cfg[$key] ?? $tweak->getDefaultConfig(), $catalog);
            $this->repo->save($pid, $cfg, $wasNew ? true : $this->repo->isActive($pid));
            Session::addMessageAfterRedirect(__('Configuration saved successfully.'));
        }
        Html::redirect($self . '?profiles_id=' . $pid);
    }

    private function handleTweakItemtypeSave(PluginUicustomItemtypeTweakInterface $tweak, string $self): void
    {
        if (!isset($_POST[$tweak->getItemtypeSaveButtonName()])) {
            return;
        }
        $pid      = (int) ($_POST['profiles_id'] ?? 0);
        $itemtype = (string) ($_POST['itemtype'] ?? '');
        if ($pid > 0 && $itemtype !== '' && preg_match('/^[A-Za-z0-9_\\\\]+$/', $itemtype)) {
            $cfg = $this->repo->getRaw($pid) ?? PluginUicustomProfileConfigRepository::defaultConfig();
            $key = $tweak->getKey();
            $cfg[$key] = $tweak->handleItemtypeSave($_POST, $cfg[$key] ?? $tweak->getDefaultConfig(), $itemtype);
            // Zapis z poziomu itemtype zawsze aktywuje regułę (jak w oryginale).
            $this->repo->save($pid, $cfg, true);
            Session::addMessageAfterRedirect(__('Configuration saved successfully.'));
        }
        Html::redirect($self . '?profiles_id=' . $pid . '&itemtype=' . rawurlencode($itemtype));
    }

    private function handleTweakItemtypeDelete(PluginUicustomItemtypeTweakInterface $tweak, string $self): void
    {
        if (!isset($_POST['delete_itemtype'])) {
            return;
        }
        $pid      = (int) ($_POST['profiles_id'] ?? 0);
        $itemtype = (string) ($_POST['itemtype'] ?? '');
        if ($pid > 0 && $itemtype !== '') {
            $cfg = $this->repo->getRaw($pid);
            if ($cfg !== null) {
                $key = $tweak->getKey();
                $cfg[$key] = $tweak->handleItemtypeDelete($cfg[$key] ?? $tweak->getDefaultConfig(), $itemtype);
                $this->repo->save($pid, $cfg, true);
                Session::addMessageAfterRedirect(__('Item successfully deleted'));
            }
        }
        Html::redirect($self . '?profiles_id=' . $pid);
    }

    /* ------------------------------ widok ------------------------------- */

    private function renderProfilesList(string $self, array $allProfiles): void
    {
        $t = fn(string $s) => PluginUicustomHtmlHelper::t($s);
        $configured = $this->repo->allMeta();
        $editPid = (int) ($_GET['profiles_id'] ?? 0);
        $card = "style='max-width:1050px;margin:1rem auto'";

        echo "<div class='card' {$card}><div class='card-body'>";
        echo "<h2 class='mb-3'>UI Customizer</h2>";
        echo "<h4>" . htmlescape($t('Configured profiles')) . "</h4>";
        if (empty($configured)) {
            echo "<p class='text-muted'>" . htmlescape($t('None – pick a profile below.')) . "</p>";
        } else {
            echo "<table class='table table-hover'><thead><tr><th>" . __('Profile') . "</th><th>" . __('Status') . "</th><th></th></tr></thead><tbody>";
            foreach ($configured as $pid => $meta) {
                $name  = $allProfiles[$pid] ?? ('#' . $pid);
                $badge = $meta['is_active']
                    ? "<span class='badge bg-success'>" . htmlescape($t('active')) . "</span>"
                    : "<span class='badge bg-secondary'>" . htmlescape($t('disabled')) . "</span>";
                echo "<tr><td>" . htmlescape($name) . "</td><td>{$badge}</td><td class='text-end'><a class='btn btn-sm btn-outline-primary' href='" . htmlescape($self . '?profiles_id=' . $pid) . "'>" . _x('button', 'Edit') . "</a></td></tr>";
            }
            echo "</tbody></table>";
        }
        echo "<div class='mt-3'><div class='mb-1 text-muted'>" . htmlescape($t('Add / edit profile:')) . "</div>";
        foreach ($allProfiles as $pid => $name) {
            $clsBtn = isset($configured[$pid]) ? 'btn-primary' : 'btn-outline-secondary';
            if ($pid === $editPid) {
                $clsBtn .= ' active border-2 border-dark';
                $name = '✎ ' . $name;
            }
            echo "<a class='btn btn-sm {$clsBtn} me-1 mb-1' href='" . htmlescape($self . '?profiles_id=' . $pid) . "'>" . htmlescape($name) . "</a>";
        }
        echo "</div></div></div>";
    }

    /** Branding globalny (kolory + logo firmy) – niezależny od profili, jedna instancja = jedno ustawienie. */
    private function renderBranding(string $self): void
    {
        $t = fn(string $s) => PluginUicustomHtmlHelper::t($s);
        $settings = new PluginUicustomBrandingSettings();
        $branding = $settings->get();
        $card = "style='max-width:1050px;margin:1rem auto'";

        echo "<form method='post' action='" . htmlescape($self) . "' enctype='multipart/form-data'>";
        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
        echo "<div class='card' {$card}><div class='card-body'>";
        echo "<h4 class='mb-2'>" . htmlescape($t('Branding')) . "</h4>";

        echo "<h6 class='mt-3'>" . htmlescape($t('Company logo')) . "</h6>";
        echo "<p class='text-muted small'>" . htmlescape($t('Replaces the GLPI logo in the header for logged-in users (login page not supported yet). PNG/JPEG/GIF/WebP, max 300 KB.')) . "</p>";
        if ($settings->hasLogo()) {
            $logoUrl = PluginUicustomHtmlHelper::pluginDir() . 'ajax/logo.php?t=' . $settings->logoUpdatedAt();
            echo "<div class='mb-2 d-flex align-items-center gap-3'>";
            echo "<img src='" . htmlescape($logoUrl) . "' alt='' style='max-height:48px;max-width:220px;background:#fff;padding:4px;border-radius:4px'>";
            echo "<button type='submit' name='remove_logo' value='1' class='btn btn-sm btn-outline-danger'>" . htmlescape($t('Remove logo')) . "</button>";
            echo "</div>";
        }
        echo "<input type='file' class='form-control' name='logo' accept='image/png,image/jpeg,image/gif,image/webp'>";

        echo "<h6 class='mt-4'>" . htmlescape($t('Colors')) . "</h6>";
        echo "<p class='text-muted small'>" . htmlescape($t('Instance-wide, applies immediately to every logged-in user. Hover/focus/active shades are computed automatically from these.')) . "</p>";
        echo "<div class='d-flex flex-wrap gap-4'>";
        foreach (PluginUicustomBrandingSettings::labels() as $key => $label) {
            echo "<div><label class='form-label d-block'>" . htmlescape($t($label)) . "</label>";
            echo "<div class='d-flex align-items-center gap-2'>";
            echo "<input type='color' class='form-control form-control-color' name='" . htmlescape($key) . "' value='" . htmlescape($branding[$key]) . "'>";
            // Wartość hex jawnie jako tekst – swatch <input type=color> bywa
            // niejednoznaczny wizualnie (ciemny kolor vs. czarny po awarii
            // inicjalizacji w niektórych przeglądarkach), tekst rozstrzyga na pewno.
            echo "<code class='small text-muted'>" . htmlescape($branding[$key]) . "</code>";
            echo "</div></div>";
        }
        echo "</div>";

        echo "<div class='mt-3 d-flex justify-content-between'>";
        echo "<button type='submit' name='reset_branding' value='1' class='btn btn-outline-secondary'>" . htmlescape($t('Reset to native GLPI colors')) . "</button>";
        echo "<button type='submit' name='save_branding' value='1' class='btn btn-primary'>" . htmlescape($t('Save branding')) . "</button>";
        echo "</div>";
        echo "</div></div></form>";
    }

    private function renderProfileLevel(int $pid, array $catalog, array $allProfiles): void
    {
        $t = fn(string $s) => PluginUicustomHtmlHelper::t($s);
        $cfg      = $this->repo->getRaw($pid);
        $isNew    = ($cfg === null);
        $cfg      = $cfg ?? PluginUicustomProfileConfigRepository::defaultConfig();
        $isActive = $isNew ? true : $this->repo->isActive($pid);
        $self     = PluginUicustomHtmlHelper::selfUrl();
        $card     = "style='max-width:1050px;margin:1rem auto'";

        echo "<form method='post' action='" . htmlescape($self) . "'>";
        echo PluginUicustomHtmlHelper::csrfAndProfileHidden($pid);
        echo "<div class='card' {$card}><div class='card-body'>";
        echo "<h3 class='mb-3'>" . htmlescape(sprintf($t('Profile rule: %s'), $allProfiles[$pid])) . ($isNew ? " <span class='badge bg-info'>" . htmlescape($t('new')) . "</span>" : "") . "</h3>";
        echo "<div class='mb-3'>" . PluginUicustomHtmlHelper::checkbox('is_active', $isActive, $t('Rule active (disabling = full view for this profile)')) . "</div>";
        echo "<div class='d-flex justify-content-between'>";
        echo "<button type='submit' name='delete' value='1' class='btn btn-outline-danger' " . ($isNew ? "disabled" : "") . ">" . _x('button', 'Delete permanently') . "</button>";
        echo "<button type='submit' name='save_status' value='1' class='btn btn-outline-primary'>" . htmlescape($t('Save status')) . "</button>";
        echo "</div>";
        echo "</div></div></form>";

        foreach (PluginUicustomTweakRegistry::all() as $tweak) {
            $tweakConfig = $cfg[$tweak->getKey()] ?? $tweak->getDefaultConfig();
            echo $tweak->renderProfileSection($tweakConfig, $pid, $catalog);
        }
    }

    private function renderItemtypeLevel(int $pid, string $itemtype, array $catalog): void
    {
        $cfg = $this->repo->getRaw($pid) ?? PluginUicustomProfileConfigRepository::defaultConfig();
        foreach (PluginUicustomTweakRegistry::all() as $tweak) {
            if ($tweak instanceof PluginUicustomItemtypeTweakInterface) {
                $tweakConfig = $cfg[$tweak->getKey()] ?? $tweak->getDefaultConfig();
                echo $tweak->renderItemtypeSection($tweakConfig, $pid, $itemtype, $catalog);
            }
        }
    }

    private function allProfiles(): array
    {
        $out = [];
        foreach ((new Profile())->find([], ['name']) as $row) {
            $out[(int) $row['id']] = $row['name'];
        }
        return $out;
    }
}
