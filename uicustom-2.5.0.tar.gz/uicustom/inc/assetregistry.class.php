<?php
/**
 * Zbiera zasoby CSS/JS zadeklarowane przez tweaki dla danego kontekstu i
 * dopiero na końcu zapisuje je do $PLUGIN_HOOKS. plugin_init_uicustom()
 * przestaje wiedzieć, JAKIE assety istnieją – pyta tylko tweaki.
 */
class PluginUicustomAssetRegistry
{
    /** @var array<string,true> zachowuje porządek wstawiania (kolejność ładowania). */
    private array $css = [];
    private array $js  = [];

    public function addCss(string $path): self
    {
        $this->css[$path] = true;
        return $this;
    }

    public function addJs(string $path): self
    {
        $this->js[$path] = true;
        return $this;
    }

    public function collect(PluginUicustomContext $context): self
    {
        foreach (PluginUicustomTweakRegistry::all() as $tweak) {
            $assets = $tweak->getAssets($context);
            foreach ($assets['css'] ?? [] as $c) {
                $this->addCss($c);
            }
            foreach ($assets['js'] ?? [] as $j) {
                $this->addJs($j);
            }
        }

        // Tryb edycji "na żywo" – niezależny od pojedynczych tweaków,
        // dostępny wyłącznie adminom (config/UPDATE).
        if ($context->isConfigAdmin()) {
            $this->addJs('js/edit-mode.js');
            $this->addCss('css/edit-mode.css');
        }

        // Branding (Config globalny, niezależny od profili i od tego, czy
        // profil ma jakąkolwiek regułę) – logo/kolor paska mają obowiązywać
        // WSZĘDZIE, nie tylko na stronach z aktywnym tweakiem. Nadpisuje
        // natywne zmienne GLPI (--glpi-mainmenu-*, --glpi-logo-*) – działa
        // niezależnie od kolejności, bo plugin CSS i tak ładuje się po
        // rdzeniu GLPI, ale dodajemy na końcu naszej listy z ostrożności.
        $this->addCss('ajax/branding.css.php');

        // Wspólny rdzeń (event bus + dom-utils) musi się wczytać PRZED
        // jakimkolwiek modułem, który go używa – stąd doklejany na start.
        if (!empty($this->js)) {
            $this->js = array_merge(
                ['js/uic-core.js' => true, 'js/uic-dom-utils.js' => true],
                $this->js
            );
        }

        return $this;
    }

    public function cssList(): array
    {
        return array_keys($this->css);
    }

    public function jsList(): array
    {
        return array_keys($this->js);
    }

    public function applyToHooks(array &$hooks): void
    {
        if (!empty($this->css)) {
            $hooks['add_css']['uicustom'] = $this->cssList();
        }
        if (!empty($this->js)) {
            $hooks['add_javascript']['uicustom'] = $this->jsList();
        }
    }
}
