<?php
/**
 * Admin-only: zapis fragmentu reguły skomponowanego w trybie edycji "na żywo".
 * MERGE do istniejącej reguły profilu (nie nadpisuje nietkniętych części).
 * Walidacja whitelistą nazw zakładek/pól współdzielona z panelem admina
 * (PluginUicustomFormsTweak::sanitizeTabsList/sanitizeFieldRule).
 *
 * POST JSON:
 * {
 *   "profiles_id": 6,
 *   "itemtype": "computer",
 *   "tabs_keep": ["Computer", ...],                    // opcjonalne
 *   "fields": { "computer.form.php": {"mode":"keep","list":[...]} }  // opcjonalne
 * }
 *
 * CSRF: kernel (CheckCsrfListener) weryfikuje nagłówek X-Glpi-Csrf-Token
 * dla żądań AJAX – nie sprawdzamy ręcznie.
 */

Session::checkRight('config', UPDATE);
header('Content-Type: application/json; charset=utf-8');

$in = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($in)) {
    http_response_code(400);
    echo '{"error":"bad_json"}';
    return;
}

$pid = (int) ($in['profiles_id'] ?? 0);
$key = strtolower((string) ($in['itemtype'] ?? ''));
if ($pid <= 0 || !preg_match('/^[a-z0-9_]+$/', $key)) {
    http_response_code(400);
    echo '{"error":"bad_target"}';
    return;
}

$repo = new PluginUicustomProfileConfigRepository();
$cfg  = $repo->getRaw($pid) ?? PluginUicustomProfileConfigRepository::defaultConfig();
if (!isset($cfg['forms'][$key])) {
    $cfg['forms'][$key] = ['tabs_keep' => [], 'fields' => [], 'cleanup' => []];
}

// Zakładki – tylko gdy przysłane (użytkownik ich dotknął).
if (array_key_exists('tabs_keep', $in) && is_array($in['tabs_keep'])) {
    $cfg['forms'][$key]['tabs_keep'] = PluginUicustomFormsTweak::sanitizeTabsList($in['tabs_keep']);
}

// Pola – merge per formularz (nadpisuje tylko przysłane akcje).
if (isset($in['fields']) && is_array($in['fields'])) {
    foreach ($in['fields'] as $action => $r) {
        if (!is_array($r)) {
            continue;
        }
        $rule = PluginUicustomFormsTweak::sanitizeFieldRule((string) $action, $r);
        if ($rule !== null) {
            $cfg['forms'][$key]['fields'][strtolower((string) $action)] = $rule;
        }
    }
}

// Zachowaj dotychczasowy stan aktywności (nowa reguła = aktywna).
$active = $repo->allMeta()[$pid]['is_active'] ?? true;
$repo->save($pid, $cfg, $active);

echo json_encode(['ok' => true, 'profiles_id' => $pid, 'itemtype' => $key]);
