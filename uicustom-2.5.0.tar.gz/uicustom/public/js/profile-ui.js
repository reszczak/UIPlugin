/*
 * UI Customizer – logika DOM sterowana konfiguracją per profil (GLPI 11.x).
 *
 * Plik ładowany przez AssetRegistry wyłącznie dla profili z aktywną regułą,
 * PO uic-core.js i uic-dom-utils.js (rdzeń: event bus + selektory wspólne
 * z edit-mode.js). Regułę "forms" pobiera z endpointu pluginu
 * (ajax/config.php), więc zakładki, pola i kosmetyka są w 100%
 * konfigurowalne z panelu – bez hardkodu.
 *
 * forms = {
 *   "<itemtype>": {
 *     "tabs_keep": ["Computer", "Item_OperatingSystem", ...],
 *     "fields": { "computer.form.php": { "mode": "keep"|"hide", "list": [...] } },
 *     "cleanup": { "hide_qr": true, "hide_all_tab": true }
 *   }
 * }
 */
(function () {
    'use strict';

    var CONFIG_URL = '/plugins/uicustom/ajax/config.php';
    var UIC = window.UIC;
    var dom = UIC.dom;
    var FORMS = null; // reguła "forms" aktywnego profilu (po fetchu)

    /* ----------------------------- tabs ------------------------------ */

    // Zwraca true, jeśli faktycznie coś ukryto (sygnał dla UIC.stabilize).
    function applyTabs(formCfg) {
        var ul = document.getElementById('tabspanel');
        if (!ul) return false;
        var keep = formCfg.tabs_keep;
        var changed = false;

        // Pusta lista = nie filtruj zakładek (bezpieczny domyślny dla nowego typu).
        if (Array.isArray(keep) && keep.length) {
            ul.querySelectorAll('li.nav-item').forEach(function (li) {
                var a = li.querySelector('a.nav-link[href*="forcetab="]');
                if (!a) return;
                var key = dom.forcetabKey(a);
                var cls = key ? key.split('$')[0] : null;
                if (cls && keep.indexOf(cls) === -1 && li.style.display !== 'none') {
                    li.style.setProperty('display', 'none', 'important');
                    changed = true;
                }
            });
        }

        if (formCfg.cleanup && formCfg.cleanup.hide_all_tab) {
            ul.querySelectorAll('a[data-show-all-tabs]').forEach(function (a) {
                var li = a.closest('li.nav-item');
                if (li && li.style.display !== 'none') {
                    li.style.setProperty('display', 'none', 'important');
                    changed = true;
                }
            });
        }

        return changed;
    }

    /* ---------------------------- fields ----------------------------- */

    function applyOneField(field, rule) {
        var list = Array.isArray(rule.list) ? rule.list : [];
        var isKeep = (rule.mode || 'keep') === 'keep';
        var inList = list.indexOf(dom.fieldName(field)) !== -1;
        var shouldHide = isKeep ? !inList : inList;
        if (shouldHide && field.style.display !== 'none') {
            field.style.setProperty('display', 'none', 'important');
            return true;
        }
        return false;
    }

    // Dopasowuje najlepszą regułę-akcję do zbioru nazw pól (heurystyka: akcja,
    // której lista pól ma najwięcej wspólnego z polami na zakładce). Pozwala
    // przypisać pola do reguły także tam, gdzie nie ma <form action> (read-only).
    function bestActionFor(fields, names) {
        var best = null, bestScore = 0;
        Object.keys(fields).forEach(function (action) {
            var list = Array.isArray(fields[action].list) ? fields[action].list : [];
            var score = 0;
            names.forEach(function (n) { if (list.indexOf(n) !== -1) score++; });
            if (score > bestScore) { bestScore = score; best = action; }
        });
        return best;
    }

    function applyFields(formCfg) {
        var fields = formCfg.fields || {};
        if (!Object.keys(fields).length) return false;
        var changed = false;

        // 1) Precyzyjnie: pola wewnątrz form[action] (profile z prawem zapisu).
        Object.keys(fields).forEach(function (action) {
            document.querySelectorAll('form[action*="' + action + '"] [data-testid^="' + dom.TESTID_PREFIX + '"]')
                .forEach(function (el) { if (applyOneField(el, fields[action])) changed = true; });
        });

        // 2) Pola SPOZA <form action> (profile read-only – GLPI nie renderuje
        //    <form>, bo nie ma zapisu). W danej chwili widoczna jest jedna
        //    zakładka, więc dopasowujemy jej pola do właściwej reguły po nazwach.
        var orphans = [];
        document.querySelectorAll('[data-testid^="' + dom.TESTID_PREFIX + '"]').forEach(function (el) {
            if (!el.closest('form[action]')) orphans.push(el);
        });
        if (!orphans.length) return changed;

        var names = orphans.map(dom.fieldName);
        var action = bestActionFor(fields, names);
        if (action) {
            orphans.forEach(function (el) { if (applyOneField(el, fields[action])) changed = true; });
        }
        return changed;
    }

    /* --------------------------- cleanup ----------------------------- */

    function applyCleanup(formCfg) {
        var c = formCfg.cleanup || {};
        var changed = false;
        if (c.hide_qr) {
            document.querySelectorAll('.asset-pictures').forEach(function (el) {
                var col = el.closest('[class*="col-"]') || el;
                if (col.style.display !== 'none') {
                    col.style.setProperty('display', 'none', 'important');
                    changed = true;
                }
            });
        }
        // fix_fa_info realizuje CSS (hide.css) – zawsze, gdy plugin aktywny.
        return changed;
    }

    /* ----------------------------- run ------------------------------- */

    // Zwraca true, jeśli ten przebieg coś zmienił – UIC.stabilize używa tego
    // do wykrycia, kiedy DOM się ustabilizował (bez zgadywania czasu).
    function apply() {
        if (!FORMS) return false;
        var type = dom.detectTabType();
        var formCfg = type ? FORMS[type] : null;
        if (!formCfg) return false;
        var changed = applyTabs(formCfg);
        if (applyFields(formCfg)) changed = true;
        if (applyCleanup(formCfg)) changed = true;
        return changed;
    }

    function start() {
        UIC.on('uic:mutate', function () { apply(); });
        apply();
        // Domyka wyścig z async-doładowywanymi polami: kontynuuje próby aż
        // do ustabilizowania DOM (nie na sztywnych timerach).
        UIC.stabilize(apply);
    }

    function init() {
        fetch(CONFIG_URL, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) {
                if (!r.ok) {
                    console.warn('uicustom: config fetch HTTP ' + r.status);
                    return {};
                }
                return r.json();
            })
            .then(function (forms) {
                FORMS = forms || {};
                start();
            })
            .catch(function (e) {
                console.warn('uicustom: config fetch failed', e);
                FORMS = {};
            });
    }

    UIC.whenReady(init);
})();
