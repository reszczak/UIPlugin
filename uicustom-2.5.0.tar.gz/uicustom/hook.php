<?php
/**
 * Cykl życia pluginu: tworzenie/utrzymanie tabeli konfiguracji per profil
 * oraz migracja starej, globalnej konfiguracji (faza 1) na model per-profil.
 */

function plugin_uicustom_install() {
    global $DB;

    $table = PLUGIN_UICUSTOM_TABLE;
    if (!$DB->tableExists($table)) {
        $sql = "CREATE TABLE `{$table}` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `profiles_id` INT UNSIGNED NOT NULL,
            `is_active` TINYINT NOT NULL DEFAULT 1,
            `config` LONGTEXT NULL,
            `date_creation` TIMESTAMP NULL DEFAULT NULL,
            `date_mod` TIMESTAMP NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `profiles_id` (`profiles_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $DB->doQuery($sql);

        plugin_uicustom_migrate_global_config();
    }

    return true;
}

function plugin_uicustom_uninstall() {
    global $DB;
    if ($DB->tableExists(PLUGIN_UICUSTOM_TABLE)) {
        $DB->doQuery('DROP TABLE `' . PLUGIN_UICUSTOM_TABLE . '`');
    }
    return true;
}

/**
 * Przenosi starą globalną konfigurację (glpi_configs, kontekst plugin:uicustom)
 * na reguły per-profil. Uruchamiana raz, przy tworzeniu tabeli.
 */
function plugin_uicustom_migrate_global_config() {
    if (!class_exists('Config')) {
        return;
    }
    $old = Config::getConfigurationValues(
        'plugin:uicustom',
        ['target_profiles', 'hidden_sectors', 'assets_menu_keep']
    );

    $profiles = array_filter(array_map('intval', explode(',', (string) ($old['target_profiles'] ?? ''))));
    if (empty($profiles)) {
        return; // świeża instalacja – admin skonfiguruje profile w panelu
    }

    $repo = new PluginUicustomProfileConfigRepository();
    foreach ($profiles as $pid) {
        $cfg = PluginUicustomProfileConfigRepository::defaultConfig();
        if (isset($old['hidden_sectors'])) {
            $cfg['menu']['hidden_sectors'] = array_values(array_filter(array_map('trim', explode(',', (string) $old['hidden_sectors']))));
        }
        if (isset($old['assets_menu_keep'])) {
            $cfg['menu']['sector_keep']['assets'] = array_values(array_filter(array_map('trim', explode(',', (string) $old['assets_menu_keep']))));
        }
        $repo->save($pid, $cfg, true);
    }

    // Sprzątamy starą globalną konfigurację.
    Config::deleteConfigurationValues(
        'plugin:uicustom',
        ['target_profiles', 'hidden_sectors', 'assets_menu_keep']
    );
}
