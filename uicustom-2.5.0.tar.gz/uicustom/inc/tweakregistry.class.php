<?php
/**
 * Rejestr wszystkich tweaków wtyczki. Silnik (AssetRegistry, AdminPanel,
 * redefine_menus) iteruje po tej liście i nie wie nic o konkretnych
 * tweakach – dodanie nowego to nowa klasa + register() poniżej.
 */
class PluginUicustomTweakRegistry
{
    /** @var array<string,PluginUicustomTweakInterface> */
    private static array $tweaks = [];
    private static bool $booted = false;

    public static function register(PluginUicustomTweakInterface $tweak): void
    {
        self::$tweaks[$tweak->getKey()] = $tweak;
    }

    /** @return PluginUicustomTweakInterface[] */
    public static function all(): array
    {
        self::boot();
        return self::$tweaks;
    }

    public static function get(string $key): ?PluginUicustomTweakInterface
    {
        self::boot();
        return self::$tweaks[$key] ?? null;
    }

    private static function boot(): void
    {
        if (self::$booted) {
            return;
        }
        self::$booted = true;

        // Tweaki wbudowane. Nowa modyfikacja UI ("np. pasek wyszukiwania",
        // "banner", "breadcrumbs") = nowa klasa implementująca
        // PluginUicustomTweakInterface + jedna linia tutaj.
        self::register(new PluginUicustomMenuTweak());
        self::register(new PluginUicustomFormsTweak());
    }
}
