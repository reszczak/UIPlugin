<?php
/**
 * Rozszerzenie PluginUicustomTweakInterface dla tweaków, które mają
 * dodatkowy poziom edycji per itemtype (dziś tylko "forms" – zakładki/pola
 * danego typu obiektu). AdminPanel sprawdza `instanceof` tego interfejsu,
 * żeby wiedzieć, który tweak obsługuje poziom 2 panelu.
 */
interface PluginUicustomItemtypeTweakInterface extends PluginUicustomTweakInterface
{
    public function getItemtypeSaveButtonName(): string;

    public function renderItemtypeSection(array $tweakConfig, int $profilesId, string $itemtype, array $catalog): string;

    public function handleItemtypeSave(array $post, array $tweakConfig, string $itemtype): array;

    public function handleItemtypeDelete(array $tweakConfig, string $itemtype): array;

    /** Krótki opis stanu konfiguracji itemtype'u, do listy na poziomie profilu. */
    public function describeItemtype(array $tweakConfig, string $itemtypeKey): string;
}
