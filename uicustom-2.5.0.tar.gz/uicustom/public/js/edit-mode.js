/*
 * UI Customizer – TRYB EDYCJI "NA ŻYWO" (Etap 1: pola + zakładki).
 *
 * Ładowany wyłącznie adminom (config/UPDATE), PO uic-core.js i
 * uic-dom-utils.js. Na stronie obiektu (jest #tabspanel) pokazuje pływający
 * przycisk "✎ UI". Po aktywacji:
 *   - wybierasz profil docelowy (pasek na dole),
 *   - klikasz pola formularza / zakładki, by przełączyć widoczne↔ukryte,
 *   - "Zapisz" MERGE'uje skomponowany fragment do reguły profilu
 *     (ajax/save_rule.php); nietknięte części reguły zostają bez zmian.
 *
 * Zapisywane są tylko "dotknięte" sekcje: zakładki – jeśli przełączono
 * choć jedną; pola – per formularz, w którym coś przełączono.
 *
 * Styl paska/oznaczeń jest w public/css/edit-mode.css (zmienne CSS, nie
 * hardkodowane kolory w JS), a śledzenie DOM korzysta ze wspólnego
 * MutationObserver rdzenia (uic-core.js) – nie tworzy własnego.
 */
(function () {
    'use strict';

    var AJAX = '/plugins/uicustom/ajax/';
    var UIC = window.UIC;
    var dom = UIC.dom;

    var PL = (document.documentElement.lang || '').toLowerCase().startsWith('pl');
    var T = PL ? {
        button:   '✎ UI',
        title:    'Tryb edycji UI',
        profile:  'Profil:',
        hint:     'Klikaj pola i zakładki, by je ukryć/pokazać dla wybranego profilu.',
        save:     'Zapisz',
        cancel:   'Anuluj',
        saved:    'Zapisano regułę.',
        nothing:  'Nic nie zmieniono – nie ma czego zapisać.',
        error:    'Błąd zapisu: ',
        noProfiles: 'Nie udało się pobrać profili.'
    } : {
        button:   '✎ UI',
        title:    'UI edit mode',
        profile:  'Profile:',
        hint:     'Click fields and tabs to hide/show them for the selected profile.',
        save:     'Save',
        cancel:   'Cancel',
        saved:    'Rule saved.',
        nothing:  'Nothing changed – nothing to save.',
        error:    'Save failed: ',
        noProfiles: 'Could not load profiles.'
    };

    var active = false;
    var targetPid = 0;
    var rule = null;          // forms-reguła profilu docelowego (z serwera)
    var dirtyTabs = false;
    var dirtyForms = {};      // action => true

    /* --------------------------- utils ------------------------------ */

    function csrf() {
        var i = document.querySelector('input[name="_glpi_csrf_token"]');
        return i ? i.value : '';
    }

    /* ----------------------- stan początkowy ------------------------ */

    // Czy element ma być oznaczony jako ukryty wg reguły profilu docelowego.
    function ruleHidesField(action, name) {
        var type = dom.detectTabType();
        var fr = rule && rule[type] && rule[type].fields && rule[type].fields[action];
        if (!fr) return false;
        var inList = Array.isArray(fr.list) && fr.list.indexOf(name) !== -1;
        return (fr.mode || 'keep') === 'keep' ? !inList : inList;
    }

    function ruleHidesTab(cls) {
        var type = dom.detectTabType();
        var keep = rule && rule[type] && rule[type].tabs_keep;
        if (!Array.isArray(keep) || !keep.length) return false;
        return keep.indexOf(cls) === -1;
    }

    /* --------------------------- marking ---------------------------- */

    function markFields(root) {
        (root.querySelectorAll ? root : document)
            .querySelectorAll('[data-testid^="' + dom.TESTID_PREFIX + '"]').forEach(function (el) {
                var form = el.closest('form');
                var action = form ? dom.formActionKey(form) : null;
                if (!action) return;
                if (!el.classList.contains('uic-editable')) {
                    el.classList.add('uic-editable');
                    el.dataset.uicAction = action;
                    if (ruleHidesField(action, dom.fieldName(el))) el.classList.add('uic-hidden');
                }
            });
    }

    function markTabs() {
        var ul = document.getElementById('tabspanel');
        if (!ul) return;
        ul.querySelectorAll('li.nav-item').forEach(function (li) {
            var a = li.querySelector('a.nav-link[href*="forcetab="]');
            if (!a) return;
            var key = dom.forcetabKey(a);
            var cls = key ? key.split('$')[0] : null;
            if (!cls || key.endsWith('$main')) return; // zakładki głównej nie ukrywamy
            if (!li.classList.contains('uic-editable')) {
                li.classList.add('uic-editable');
                li.dataset.uicTab = cls;
                if (ruleHidesTab(cls)) li.classList.add('uic-hidden');
            }
        });
    }

    function unmarkAll() {
        document.querySelectorAll('.uic-editable').forEach(function (el) {
            el.classList.remove('uic-editable', 'uic-hidden');
            delete el.dataset.uicAction;
            delete el.dataset.uicTab;
        });
    }

    /* --------------------------- klik ------------------------------- */

    function onClick(e) {
        if (!active) return;
        if (e.target.closest('#uic-toolbar') || e.target.closest('#uic-fab')) return;

        var field = e.target.closest('[data-testid^="' + dom.TESTID_PREFIX + '"].uic-editable');
        if (field) {
            e.preventDefault(); e.stopPropagation();
            field.classList.toggle('uic-hidden');
            dirtyForms[field.dataset.uicAction] = true;
            return;
        }
        var tab = e.target.closest('li.uic-editable[data-uic-tab]');
        if (tab) {
            e.preventDefault(); e.stopPropagation();
            tab.classList.toggle('uic-hidden');
            dirtyTabs = true;
        }
    }

    /* --------------------------- zapis ------------------------------ */

    function composePayload() {
        var type = dom.detectTabType();
        var payload = { profiles_id: targetPid, itemtype: type };

        if (dirtyTabs) {
            var keep = [];
            document.querySelectorAll('#tabspanel li.nav-item').forEach(function (li) {
                var a = li.querySelector('a.nav-link[href*="forcetab="]');
                if (!a) return;
                var key = dom.forcetabKey(a);
                var cls = key ? key.split('$')[0] : null;
                if (!cls) return;
                // Główna zakładka zawsze zostaje; reszta wg stanu edycji.
                if (key.endsWith('$main') || !li.classList.contains('uic-hidden')) {
                    if (keep.indexOf(cls) === -1) keep.push(cls);
                }
            });
            payload.tabs_keep = keep;
        }

        var fields = {};
        Object.keys(dirtyForms).forEach(function (action) {
            var list = [];
            document.querySelectorAll('[data-uic-action="' + action + '"]').forEach(function (el) {
                if (!el.classList.contains('uic-hidden')) list.push(dom.fieldName(el));
            });
            fields[action] = { mode: 'keep', list: list };
        });
        if (Object.keys(fields).length) payload.fields = fields;

        return payload;
    }

    function save() {
        if (!dirtyTabs && !Object.keys(dirtyForms).length) {
            alert(T.nothing);
            return;
        }
        fetch(AJAX + 'save_rule.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-Glpi-Csrf-Token': csrf()
            },
            body: JSON.stringify(composePayload())
        })
            .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
            .then(function (res) {
                if (res.ok && res.j.ok) { alert(T.saved); exit(); }
                else { alert(T.error + JSON.stringify(res.j)); }
            })
            .catch(function (e) { alert(T.error + e); });
    }

    /* ------------------------- toolbar/fab -------------------------- */

    function buildToolbar(profiles) {
        var bar = document.createElement('div');
        bar.id = 'uic-toolbar';
        var opts = profiles.map(function (p) {
            return '<option value="' + p.id + '">' + p.name + (p.has_rule ? ' ●' : '') + '</option>';
        }).join('');
        bar.innerHTML =
            '<strong>' + T.title + '</strong>' +
            '<label>' + T.profile + ' <select id="uic-profile">' + opts + '</select></label>' +
            '<span class="uic-hint">' + T.hint + '</span>' +
            '<span class="uic-spacer"></span>' +
            '<button class="uic-btn uic-save">' + T.save + '</button>' +
            '<button class="uic-btn uic-cancel">' + T.cancel + '</button>';
        document.body.appendChild(bar);

        var sel = bar.querySelector('#uic-profile');
        // Domyślnie pierwszy profil z regułą (najczęstszy scenariusz).
        var withRule = profiles.find(function (p) { return p.has_rule; });
        if (withRule) sel.value = String(withRule.id);
        targetPid = parseInt(sel.value, 10);

        sel.addEventListener('change', function () {
            targetPid = parseInt(sel.value, 10);
            reloadRule();
        });
        bar.querySelector('.uic-save').addEventListener('click', save);
        bar.querySelector('.uic-cancel').addEventListener('click', exit);
    }

    function reloadRule() {
        dirtyTabs = false;
        dirtyForms = {};
        unmarkAll();
        fetch(AJAX + 'config.php?profiles_id=' + targetPid, {
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
            .then(function (r) { return r.ok ? r.json() : {}; })
            .then(function (forms) {
                rule = forms || {};
                markFields(document);
                markTabs();
            })
            .catch(function () { rule = {}; markFields(document); markTabs(); });
    }

    // Subskrybent wspólnego MutationObserver rdzenia – zastępuje prywatny
    // observer, który ten plik tworzył wcześniej wyłącznie dla siebie.
    function onMutate(detail) {
        if (!active) return;
        (detail.addedNodes || []).forEach(function (n) { markFields(n); });
    }

    function enter() {
        if (active) return;
        active = true;
        fetch(AJAX + 'profiles.php', {
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (profiles) {
                if (!profiles) { alert(T.noProfiles); active = false; return; }
                buildToolbar(profiles);
                reloadRule();
                UIC.on('uic:mutate', onMutate);
            })
            .catch(function () { alert(T.noProfiles); active = false; });
    }

    function exit() {
        active = false;
        UIC.off('uic:mutate', onMutate);
        unmarkAll();
        var bar = document.getElementById('uic-toolbar');
        if (bar) bar.remove();
        dirtyTabs = false;
        dirtyForms = {};
    }

    /* ---------------------------- init ------------------------------ */

    function init() {
        // Idempotencja: skrypt bywa ewaluowany/odpalany wielokrotnie (AJAX,
        // re-run) – bez tego listenery dublują się i toggle wykonuje się 2×.
        if (window.__uicEditModeInit) return;
        // Tylko strony obiektów (jest pasek zakładek).
        if (!document.getElementById('tabspanel')) return;
        window.__uicEditModeInit = true;

        var fab = document.createElement('button');
        fab.id = 'uic-fab';
        fab.type = 'button';
        fab.textContent = T.button;
        fab.title = T.title;
        fab.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            active ? exit() : enter();
        });
        document.body.appendChild(fab);

        document.addEventListener('click', onClick, true); // capture – przed nawigacją
    }

    UIC.whenReady(init);
})();
