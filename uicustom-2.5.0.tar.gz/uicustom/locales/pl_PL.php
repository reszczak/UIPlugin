<?php
/**
 * Tłumaczenia PL dla domeny 'uicustom' (format Laminas 'phparray').
 * Klucz = angielskie źródło z __('...', 'uicustom'), wartość = polski.
 */
return [
    'Configured profiles' => 'Skonfigurowane profile',
    'None – pick a profile below.' => 'Brak – wybierz profil poniżej.',
    'active' => 'aktywna',
    'disabled' => 'wyłączona',
    'Add / edit profile:' => 'Dodaj / edytuj profil:',
    'No sample object of this type exists in GLPI – create one to scan available tabs and fields.'
        => 'Brak przykładowego obiektu tego typu w GLPI – utwórz jeden, aby zescanować dostępne zakładki i pola.',
    'No editable fields detected for this type.' => 'Nie wykryto edytowalnych pól dla tego typu.',
    'Tabs – keep' => 'Zakładki – zostaw',
    '(no data – a sample object is required)' => '(brak danych – potrzebny przykładowy obiekt)',
    'Form fields' => 'Pola formularzy',
    'Mode:' => 'Tryb:',
    'Keep only selected' => 'Zostaw tylko zaznaczone',
    'Hide selected' => 'Ukryj zaznaczone',
    'None of the kept tabs has editable fields.' => 'Żadna z zostawionych zakładek nie ma edytowalnych pól.',
    'Tabs without editable fields (sub-item lists): %s. They can only be kept/hidden as a whole above.'
        => 'Zakładki bez edytowalnych pól (listy pod-obiektów): %s. Można je tylko zostawić/ukryć w całości powyżej.',
    'Cosmetics' => 'Kosmetyka',
    'Hide QR / Asset URL card' => 'Ukryj kartę QR / Asset URL',
    'Hide the "All" tab' => 'Ukryj zakładkę „All”',
    'Fix the dropdown "i" icon' => 'Napraw ikonę „i” dropdownów',
    'Mode "Keep only selected" = whitelist. "Hide selected" = blacklist. Fields detected from object #%d.'
        => 'Tryb „Zostaw tylko zaznaczone” = whitelist. „Ukryj zaznaczone” = blacklist. Pola wykryte na podstawie obiektu #%d.',
    'Delete rule for this type' => 'Usuń regułę dla tego typu',
    'Profile rule: %s' => 'Reguła profilu: %s',
    'new' => 'nowy',
    'Rule active (disabling = full view for this profile)' => 'Reguła aktywna (wyłączenie = pełny widok dla tego profilu)',
    'Hide menu sectors' => 'Ukryj sektory menu',
    'Assets – keep items' => 'Assets – zostaw pozycje',
    'Empty = do not filter the Assets sector.' => 'Puste = nie filtruj sektora Assets.',
    'Menu cosmetics' => 'Kosmetyka menu',
    'Hide the Dashboard link in Assets' => 'Ukryj link Dashboard w Assets',
    'Save menu' => 'Zapisz menu',
    'Menu' => 'Menu',
    'Sector' => 'Sektor',
    'Hide whole' => 'Ukryj cały',
    'Keep only these items (empty = all)' => 'Zostaw tylko te pozycje (puste = wszystkie)',
    'Hide all dashboard links' => 'Ukryj wszystkie linki Dashboard',
    'Configure a type (tabs & fields):' => 'Skonfiguruj typ (zakładki i pola):',
    'profile: %s' => 'profil: %s',
    'Forms (tabs and fields) per type' => 'Formularze (zakładki i pola) per typ',
    'None – add a type below.' => 'Brak – dodaj typ poniżej.',
    '%d tabs, %d forms with field rules' => '%d zakładek, %d formularzy z regułą pól',
    'Add / edit type:' => 'Dodaj / edytuj typ:',
];
