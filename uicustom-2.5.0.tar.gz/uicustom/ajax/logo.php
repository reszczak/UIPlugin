<?php
/**
 * Serwuje wgrane logo firmy (bytes z bazy, patrz PluginUicustomBrandingSettings).
 * BEZ wymogu sesji – logo nie jest daną wrażliwą (publiczny branding
 * instancji), więc brak Session::checkRight jest tu zamierzony.
 *
 * Aktualnie linkowane tylko z ajax/branding.css.php, które ładuje się
 * WYŁĄCZNIE dla zalogowanych użytkowników (patrz notatka tam) – logo na
 * ekranie logowania nie jest jeszcze wsparte.
 */

$logo = (new PluginUicustomBrandingSettings())->getLogo();
if ($logo === null) {
    http_response_code(404);
    return;
}

header('Content-Type: ' . $logo['mime']);
// URL zawiera ?t=<timestamp ostatniej zmiany> (patrz branding.css.php) –
// bezpiecznie długi cache, bo zmiana logo zawsze dostaje nowy URL.
header('Cache-Control: public, max-age=604800, immutable');
echo $logo['data'];
