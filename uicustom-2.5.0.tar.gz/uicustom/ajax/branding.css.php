<?php
/**
 * Generuje :root { --glpi-mainmenu-*; --glpi-logo-* } na podstawie ustawień
 * brandingu (Config, kontekst 'plugin:uicustom'). Rejestrowany przez
 * AssetRegistry pod add_css – wyłącznie dla stron ZALOGOWANEGO użytkownika.
 *
 * NIE rejestrować pod add_css_anonymous_page (ekran logowania)! Zweryfikowane
 * empirycznie: dodatkowe żądanie przez pełny kernel GLPI w trakcie
 * renderowania strony logowania psuje token CSRF formularza logowania
 * ("Akcja nie jest możliwa" przy próbie zalogowania) – blokuje WSZYSTKICH
 * użytkowników, nie tylko adminów. Logo na ekranie logowania wymaga innego
 * mechanizmu (prawdziwie statyczny plik, bez wykonania PHP na tej stronie)
 * – nierozwiązane, patrz notatka w setup.php.
 *
 * Cache-Control: no-cache – w przeciwieństwie do statycznych plików w
 * public/, ten endpoint zmienia treść w czasie działania (zapis w panelu),
 * niezależnie od wersji pluginu (?v=), więc nie może być cache'owany tak
 * jak zwykłe assety.
 */

global $CFG_GLPI;

header('Content-Type: text/css; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

$settings = new PluginUicustomBrandingSettings();
$colors   = $settings->get();

echo ":root {\n";
foreach ($colors as $key => $value) {
    $cssVar = PluginUicustomBrandingSettings::CSS_VARS[$key] ?? null;
    if ($cssVar !== null) {
        echo "  {$cssVar}: {$value};\n";
    }
}

// --tblr-primary same nie starcza: Tabler/GLPI liczą hover/active (--tblr-primary-darken)
// i subtelne tła/focus-ring (rgba(var(--tblr-primary-rgb), .25) itd.) z tych
// dwóch DODATKOWYCH zmiennych, nie tylko z --tblr-primary. Bez nich przycisk
// zmieniłby kolor "w spoczynku", ale hover/focus/subtelne tło zostałyby stare.
echo "  --tblr-primary-rgb: " . PluginUicustomBrandingSettings::hexToRgbTriple($colors['brand_primary']) . ";\n";
echo "  --tblr-primary-fg: " . PluginUicustomBrandingSettings::contrastingForeground($colors['brand_primary']) . ";\n";

// --tblr-link-color-rgb: druga forma tej samej wartości, konsumowana przez
// rgba()/color-mix() w regule bazowej "a { color: ... }" (patrz tabler.min.css).
// --tblr-link-hover-color(-rgb): GLPI NIE liczy tego automatycznie z
// --tblr-link-color (w przeciwieństwie do primary-darken) - trzeba policzyć
// przyciemniony odcień samemu w PHP.
$linkHover = PluginUicustomBrandingSettings::darken($colors['brand_link'], 0.2);
echo "  --tblr-link-color-rgb: " . PluginUicustomBrandingSettings::hexToRgbTriple($colors['brand_link']) . ";\n";
echo "  --tblr-link-hover-color: {$linkHover};\n";
echo "  --tblr-link-hover-color-rgb: " . PluginUicustomBrandingSettings::hexToRgbTriple($linkHover) . ";\n";

if ($settings->hasLogo()) {
    $logoUrl = ($CFG_GLPI['root_doc'] ?? '') . '/plugins/uicustom/ajax/logo.php?t=' . $settings->logoUpdatedAt();
    foreach (PluginUicustomBrandingSettings::logoCssVars() as $cssVar) {
        echo "  {$cssVar}: url('{$logoUrl}');\n";
    }
}

echo "}\n";

if ($settings->hasLogo()) {
    // .glpi-logo (css/includes/_base.scss) ma sztywny box (100x55px w
    // rozwiniętym sidebarze, 40x40px w zwiniętym) i domyślnie BEZ
    // background-size – natywne logo GLPI jest już wstępnie przycięte do
    // tych proporcji, więc działa bez skalowania. Wgrany obraz użytkownika
    // ma dowolne proporcje/rozmiar, więc bez tego wymuszenia jest widoczny
    // tylko lewy górny róg (natural size + no-repeat = przycięcie, nie
    // skalowanie). "contain" jest bezpieczne dla natywnego logo też
    // (już dopasowane, więc to no-op wizualnie).
    echo ".glpi-logo { background-size: contain !important; background-position: center !important; }\n";
}
